// 🧹 Correctif pour l'auto-nettoyage du dossier temporaire
const fs = require('fs');
const path = require('path');

// Redirection du stockage temporaire
const customTemp = path.join(process.cwd(), 'temp');
if (!fs.existsSync(customTemp)) fs.mkdirSync(customTemp, { recursive: true });
process.env.TMPDIR = customTemp;
process.env.TEMP = customTemp;
process.env.TMP = customTemp;

// Nettoyage automatique toutes les 3 heures
setInterval(() => {
    fs.readdir(customTemp, (err, files) => {
        if (err) return;
        for (const file of files) {
            const filePath = path.join(customTemp, file);
            fs.stat(filePath, (err, stats) => {
                if (!err && Date.now() - stats.mtimeMs > 3 * 60 * 60 * 1000) {
                    fs.unlink(filePath, () => { });
                }
            });
        }
    });
    console.log('🧹 Dossier temporaire nettoyé automatiquement');
}, 3 * 60 * 60 * 1000);

const settings = require('./settings');
require('./config.js');
const { isBanned } = require('./lib/isBanned');
const yts = require('yt-search');
const { fetchBuffer } = require('./lib/myfunc');
const fetch = require('node-fetch');
const ytdl = require('ytdl-core');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const { isSudo } = require('./lib/index');
const isOwnerOrSudo = require('./lib/isOwner');
const isAdmin = require('./lib/isAdmin');
const { Antilink } = require('./lib/antilink');
const { handleAntiBadwordCommand, handleBadwordDetection } = require('./lib/antibadword');
const { addCommandReaction, handleAreactCommand } = require('./lib/reactions');

// 🔄 CHARGEMENT DYNAMIQUE DES COMMANDES (Évite les erreurs MODULE_NOT_FOUND)
const commands = {};
const commandsPath = path.join(__dirname, 'commands');

if (fs.existsSync(commandsPath)) {
    fs.readdirSync(commandsPath).forEach(file => {
        if (file.endsWith('.js')) {
            const commandName = file.replace('.js', '');
            try {
                commands[commandName] = require(`./commands/${file}`);
            } catch (err) {
                console.log(`⚠️ Impossible de charger la commande: ${file}`);
            }
        }
    });
}

// Extraction sécurisée des fonctions de commande chargées
const autotypingModule = commands.autotyping || {};
const handleAutotypingForMessage = autotypingModule.handleAutotypingForMessage || (async () => {});
const showTypingAfterCommand = autotypingModule.showTypingAfterCommand || (async () => {});

const autoreadModule = commands.autoread || {};
const handleAutoread = autoreadModule.handleAutoread || (async () => {});

const antideleteModule = commands.antidelete || {};
const handleMessageRevocation = antideleteModule.handleMessageRevocation || (async () => {});
const storeMessage = antideleteModule.storeMessage || (() => {});

const tictactoeModule = commands.tictactoe || {};
const handleTicTacToeMove = tictactoeModule.handleTicTacToeMove || (async () => {});

const topmembersModule = commands.topmembers || {};
const incrementMessageCount = topmembersModule.incrementMessageCount || (() => {});
const topMembers = topmembersModule.topMembers || (() => {});

const antilinkModule = commands.antilink || {};
const handleAntilinkCommand = antilinkModule.handleAntilinkCommand || (async () => {});

const antitagModule = commands.antitag || {};
const handleAntitagCommand = antitagModule.handleAntitagCommand || (async () => {});
const handleTagDetection = antitagModule.handleTagDetection || (async () => {});

const mentionModule = commands.mention || {};
const handleMentionDetection = mentionModule.handleMentionDetection || (async () => {});
const mentionToggleCommand = mentionModule.mentionToggleCommand || (async () => {});
const setMentionCommand = mentionModule.setMentionCommand || (async () => {});

const hangmanModule = commands.hangman || {};
const startHangman = hangmanModule.startHangman || (() => {});
const guessLetter = hangmanModule.guessLetter || (() => {});

const triviaModule = commands.trivia || {};
const startTrivia = triviaModule.startTrivia || (() => {});
const answerTrivia = triviaModule.answerTrivia || (() => {});

const welcomeModule = commands.welcome || {};
const handleJoinEvent = welcomeModule.handleJoinEvent || (async () => {});

const goodbyeModule = commands.goodbye || {};
const handleLeaveEvent = goodbyeModule.handleLeaveEvent || (async () => {});

const chatbotModule = commands.chatbot || {};
const handleChatbotCommand = chatbotModule.handleChatbotCommand || (async () => {});
const handleChatbotResponse = chatbotModule.handleChatbotResponse || (async () => {});

const promoteModule = commands.promote || {};
const handlePromotionEvent = promoteModule.handlePromotionEvent || (async () => {});

const demoteModule = commands.demote || {};
const handleDemotionEvent = demoteModule.handleDemotionEvent || (async () => {});

const autostatusModule = commands.autostatus || {};
const handleStatusUpdate = autostatusModule.handleStatusUpdate || (async () => {});

const anticallModule = commands.anticall || {};
const pmblockerModule = commands.pmblocker || {};
const readPmBlockerState = pmblockerModule.readState || (() => ({ enabled: false }));

const piesModule = commands.pies || {};
const piesCommand = piesModule.piesCommand || (async () => {});
const piesAlias = piesModule.piesAlias || (async () => {});

const removebgCommand = commands.removebg || { exec: async () => {} };
const reminiModule = commands.remini || {};
const reminiCommand = reminiModule.reminiCommand || (async () => {});

// Configuration globale
global.packname = settings.packname;
global.author = settings.author;
global.channelLink = "";
global.ytch = "CRYXEN2109";

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '',
            newsletterName: '⚡ C R Y X E N 2 1 0 9 ⚡',
            serverMessageId: -1
        }
    }
};

async function handleMessages(sock, messageUpdate, printLog) {
    try {
        const { messages, type } = messageUpdate;
        if (type !== 'notify') return;

        const message = messages[0];
        if (!message?.message) return;

        await handleAutoread(sock, message);

        if (message.message) {
            storeMessage(sock, message);
        }

        if (message.message?.protocolMessage?.type === 0) {
            await handleMessageRevocation(sock, message);
            return;
        }

        const chatId = message.key.remoteJid;
        const senderId = message.key.participant || message.key.remoteJid;
        const isGroup = chatId.endsWith('@g.us');
        const senderIsSudo = await isSudo(senderId);
        const senderIsOwnerOrSudo = await isOwnerOrSudo(senderId, sock, chatId);

        // Boutons de réponse
        if (message.message?.buttonsResponseMessage) {
            const buttonId = message.message.buttonsResponseMessage.selectedButtonId;
            const chatId = message.key.remoteJid;

            if (buttonId === 'owner') {
                if (commands.owner) await commands.owner(sock, chatId);
                return;
            }
        }

        const userMessage = (
            message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            message.message?.buttonsResponseMessage?.selectedButtonId?.trim() ||
            ''
        ).toLowerCase().replace(/\.\s+/g, '.').trim();

        const rawText = message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            '';

        if (userMessage.startsWith('.')) {
            console.log(`📝 Commande utilisée dans le salon ${isGroup ? 'Groupe' : 'Privé'}: ${userMessage}`);
        }

        let isPublic = true;
        try {
            const data = JSON.parse(fs.readFileSync('./data/messageCount.json'));
            if (typeof data.isPublic === 'boolean') isPublic = data.isPublic;
        } catch (error) {
            console.error('Erreur lors de la vérification du mode d\'accès:', error);
        }
        
        const isOwnerOrSudoCheck = message.key.fromMe || senderIsOwnerOrSudo;

        if (isBanned(senderId) && !userMessage.startsWith('.unban')) {
            if (Math.random() < 0.1) {
                await sock.sendMessage(chatId, {
                    text: '❌ Vous êtes banni de l\'utilisation du bot. Contactez un administrateur.',
                    ...channelInfo
                });
            }
            return;
        }

        if (/^[1-9]$/.test(userMessage) || userMessage.toLowerCase() === 'surrender') {
            await handleTicTacToeMove(sock, chatId, senderId, userMessage);
            return;
        }

        if (!message.key.fromMe) incrementMessageCount(chatId, senderId);

        if (isGroup) {
            if (userMessage) {
                await handleBadwordDetection(sock, chatId, message, userMessage, senderId);
            }
            await Antilink(message, sock);
        }

        if (!isGroup && !message.key.fromMe && !senderIsSudo) {
            try {
                const pmState = readPmBlockerState();
                if (pmState.enabled) {
                    await sock.sendMessage(chatId, { text: pmState.message || 'Les messages privés sont bloqués. Veuillez contacter le propriétaire en groupe uniquement.' });
                    await new Promise(r => setTimeout(r, 1500));
                    try { await sock.updateBlockStatus(chatId, 'block'); } catch (e) { }
                    return;
                }
            } catch (e) { }
        }

        if (!userMessage.startsWith('.')) {
            await handleAutotypingForMessage(sock, chatId, userMessage);

            if (isGroup) {
                await handleTagDetection(sock, chatId, message, senderId);
                await handleMentionDetection(sock, chatId, message);

                if (isPublic || isOwnerOrSudoCheck) {
                    await handleChatbotResponse(sock, chatId, message, userMessage, senderId);
                }
            }
            return;
        }

        if (!isPublic && !isOwnerOrSudoCheck) {
            return;
        }

        const adminCommands = ['.mute', '.unmute', '.ban', '.unban', '.promote', '.demote', '.kick', '.tagall', '.tagnotadmin', '.hidetag', '.antilink', '.antitag', '.setgdesc', '.setgname', '.setgpp'];
        const isAdminCommand = adminCommands.some(cmd => userMessage.startsWith(cmd));

        const ownerCommands = ['.mode', '.autostatus', '.antidelete', '.cleartmp', '.setpp', '.clearsession', '.areact', '.autoreact', '.autotyping', '.autoread', '.pmblocker'];
        const isOwnerCommand = ownerCommands.some(cmd => userMessage.startsWith(cmd));

        let isSenderAdmin = false;
        let isBotAdmin = false;

        if (isGroup && isAdminCommand) {
            const adminStatus = await isAdmin(sock, chatId, senderId);
            isSenderAdmin = adminStatus.isSenderAdmin;
            isBotAdmin = adminStatus.isBotAdmin;

            if (!isBotAdmin) {
                await sock.sendMessage(chatId, { text: 'Veuillez nommer le bot administrateur pour exécuter les commandes d\'administration.', ...channelInfo }, { quoted: message });
                return;
            }

            if (
                userMessage.startsWith('.mute') ||
                userMessage === '.unmute' ||
                userMessage.startsWith('.ban') ||
                userMessage.startsWith('.unban') ||
                userMessage.startsWith('.promote') ||
                userMessage.startsWith('.demote')
            ) {
                if (!isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, {
                        text: 'Désolé, seuls les administrateurs du groupe peuvent utiliser cette commande.',
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }
            }
        }

        if (isOwnerCommand) {
            if (!message.key.fromMe && !senderIsOwnerOrSudo) {
                await sock.sendMessage(chatId, { text: '❌ Cette commande est réservée au propriétaire ou au Sudo !' }, { quoted: message });
                return;
            }
        }

        let commandExecuted = false;

        switch (true) {
            case userMessage === '.simage': {
                const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                if (quotedMessage?.stickerMessage && commands.simage) {
                    await commands.simage(sock, quotedMessage, chatId);
                } else {
                    await sock.sendMessage(chatId, { text: 'Veuillez répondre à un sticker avec la commande .simage pour le convertir.', ...channelInfo }, { quoted: message });
                }
                commandExecuted = true;
                break;
            }
            case userMessage.startsWith('.kick'):
                if (commands.kick) {
                    const mentionedJidListKick = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    await commands.kick(sock, chatId, senderId, mentionedJidListKick, message);
                }
                break;
            case userMessage.startsWith('.mute'):
                if (commands.mute) {
                    const parts = userMessage.trim().split(/\s+/);
                    const muteArg = parts[1];
                    const muteDuration = muteArg !== undefined ? parseInt(muteArg, 10) : undefined;
                    if (muteArg !== undefined && (isNaN(muteDuration) || muteDuration <= 0)) {
                        await sock.sendMessage(chatId, { text: 'Veuillez indiquer un nombre de minutes valide ou utilisez .mute sans paramètre pour rendre muet immédiatement.', ...channelInfo }, { quoted: message });
                    } else {
                        await commands.mute(sock, chatId, senderId, message, muteDuration);
                    }
                }
                break;
            case userMessage === '.unmute':
                if (commands.unmute) await commands.unmute(sock, chatId, senderId);
                break;
            case userMessage.startsWith('.ban'):
                if (commands.ban) {
                    if (!isGroup && !message.key.fromMe && !senderIsSudo) {
                        await sock.sendMessage(chatId, { text: 'Seul le propriétaire/sudo peut utiliser .ban en message privé.' }, { quoted: message });
                        break;
                    }
                    await commands.ban(sock, chatId, message);
                }
                break;
            case userMessage.startsWith('.unban'):
                if (commands.unban) {
                    if (!isGroup && !message.key.fromMe && !senderIsSudo) {
                        await sock.sendMessage(chatId, { text: 'Seul le propriétaire/sudo peut utiliser .unban en message privé.' }, { quoted: message });
                        break;
                    }
                    await commands.unban(sock, chatId, message);
                }
                break;
            case userMessage === '.help' || userMessage === '.menu' || userMessage === '.bot' || userMessage === '.list':
                if (commands.help) await commands.help(sock, chatId, message, "");
                commandExecuted = true;
                break;
            case userMessage === '.sticker' || userMessage === '.s':
                if (commands.sticker) await commands.sticker(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.warnings'):
                if (commands.warnings) {
                    const mentionedJidListWarnings = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    await commands.warnings(sock, chatId, mentionedJidListWarnings);
                }
                break;
            case userMessage.startsWith('.warn'):
                if (commands.warn) {
                    const mentionedJidListWarn = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    await commands.warn(sock, chatId, senderId, mentionedJidListWarn, message);
                }
                break;
            case userMessage.startsWith('.tts'):
                if (commands.tts) {
                    const text = userMessage.slice(4).trim();
                    await commands.tts(sock, chatId, text, message);
                }
                break;
            case userMessage.startsWith('.delete') || userMessage.startsWith('.del'):
                if (commands.delete) await commands.delete(sock, chatId, message, senderId);
                break;
            case userMessage.startsWith('.attp'):
                if (commands.attp) await commands.attp(sock, chatId, message);
                break;
            case userMessage === '.settings':
                if (commands.settings) await commands.settings(sock, chatId, message);
                break;
            case userMessage.startsWith('.mode'):
                if (!message.key.fromMe && !senderIsOwnerOrSudo) {
                    await sock.sendMessage(chatId, { text: 'Seul le propriétaire du bot peut utiliser cette commande !', ...channelInfo }, { quoted: message });
                    return;
                }
                let data;
                try {
                    data = JSON.parse(fs.readFileSync('./data/messageCount.json'));
                } catch (error) {
                    console.error('Erreur de lecture du mode:', error);
                    await sock.sendMessage(chatId, { text: 'Échec de la lecture du mode du bot', ...channelInfo });
                    return;
                }

                const action = userMessage.split(' ')[1]?.toLowerCase();
                if (!action) {
                    const currentMode = data.isPublic ? 'public' : 'privé';
                    await sock.sendMessage(chatId, {
                        text: `Mode actuel du bot : *${currentMode}*\n\nUtilisation: .mode public/private\n\nExemple:\n.mode public - Autoriser tout le monde\n.mode private - Restreindre au propriétaire`,
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }

                if (action !== 'public' && action !== 'private') {
                    await sock.sendMessage(chatId, {
                        text: 'Utilisation: .mode public/private\n\nExemple:\n.mode public - Autoriser tout le monde\n.mode private - Restreindre au propriétaire',
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }

                try {
                    data.isPublic = action === 'public';
                    fs.writeFileSync('./data/messageCount.json', JSON.stringify(data, null, 2));
                    await sock.sendMessage(chatId, { text: `Le bot est maintenant en mode *${action === 'public' ? 'Public' : 'Privé'}*`, ...channelInfo });
                } catch (error) {
                    console.error('Erreur lors de la mise à jour du mode:', error);
                    await sock.sendMessage(chatId, { text: 'Échec de la mise à jour du mode du bot', ...channelInfo });
                }
                break;
            case userMessage.startsWith('.anticall'):
                if (!message.key.fromMe && !senderIsOwnerOrSudo) {
                    await sock.sendMessage(chatId, { text: 'Seul le propriétaire/sudo peut utiliser anticall.' }, { quoted: message });
                    break;
                }
                if (commands.anticall) {
                    const args = userMessage.split(' ').slice(1).join(' ');
                    await commands.anticall.anticallCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.pmblocker'):
                if (commands.pmblocker) {
                    const args = userMessage.split(' ').slice(1).join(' ');
                    await commands.pmblocker.pmblockerCommand(sock, chatId, message, args);
                }
                commandExecuted = true;
                break;
            case userMessage === '.owner':
                if (commands.owner) await commands.owner(sock, chatId);
                break;
            case userMessage === '.tagall':
                if (commands.tagall) await commands.tagall(sock, chatId, senderId, message);
                break;
            case userMessage === '.tagnotadmin':
                if (commands.tagnotadmin) await commands.tagnotadmin(sock, chatId, senderId, message);
                break;
            case userMessage.startsWith('.hidetag'):
                if (commands.hidetag) {
                    const messageText = rawText.slice(8).trim();
                    const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
                    await commands.hidetag(sock, chatId, senderId, messageText, replyMessage, message);
                }
                break;
            case userMessage.startsWith('.tag'):
                if (commands.tag) {
                    const messageText = rawText.slice(4).trim();
                    const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
                    await commands.tag(sock, chatId, senderId, messageText, replyMessage, message);
                }
                break;
            case userMessage.startsWith('.antilink'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans les groupes.', ...channelInfo }, { quoted: message });
                    return;
                }
                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, { text: 'Veuillez d\'abord mettre le bot administrateur.', ...channelInfo }, { quoted: message });
                    return;
                }
                await handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                break;
            case userMessage.startsWith('.antitag'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans les groupes.', ...channelInfo }, { quoted: message });
                    return;
                }
                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, { text: 'Veuillez d\'abord mettre le bot administrateur.', ...channelInfo }, { quoted: message });
                    return;
                }
                await handleAntitagCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                break;
            case userMessage === '.meme':
                if (commands.meme) await commands.meme(sock, chatId, message);
                break;
            case userMessage === '.joke':
                if (commands.joke) await commands.joke(sock, chatId, message);
                break;
            case userMessage === '.quote':
                if (commands.quote) await commands.quote(sock, chatId, message);
                break;
            case userMessage === '.fact':
                if (commands.fact) await commands.fact(sock, chatId, message, message);
                break;
            case userMessage.startsWith('.weather'):
                if (commands.weather) {
                    const city = userMessage.slice(9).trim();
                    if (city) {
                        await commands.weather(sock, chatId, message, city);
                    } else {
                        await sock.sendMessage(chatId, { text: 'Veuillez préciser une ville, ex: .weather Paris', ...channelInfo }, { quoted: message });
                    }
                }
                break;
            case userMessage === '.news':
                if (commands.news) await commands.news(sock, chatId);
                break;
            case userMessage.startsWith('.ttt') || userMessage.startsWith('.tictactoe'):
                if (commands.tictactoe) {
                    const tttText = userMessage.split(' ').slice(1).join(' ');
                    await commands.tictactoe.tictactoeCommand(sock, chatId, senderId, tttText);
                }
                break;
            case userMessage.startsWith('.move'):
                const position = parseInt(userMessage.split(' ')[1]);
                if (isNaN(position)) {
                    await sock.sendMessage(chatId, { text: 'Veuillez fournir un numéro de case valide pour le Tic-Tac-Toe.', ...channelInfo }, { quoted: message });
                } else {
                    handleTicTacToeMove(sock, chatId, senderId, position);
                }
                break;
            case userMessage === '.topmembers':
                topMembers(sock, chatId, isGroup);
                break;
            case userMessage.startsWith('.hangman'):
                startHangman(sock, chatId);
                break;
            case userMessage.startsWith('.guess'):
                const guessedLetter = userMessage.split(' ')[1];
                if (guessedLetter) {
                    guessLetter(sock, chatId, guessedLetter);
                } else {
                    sock.sendMessage(chatId, { text: 'Proposez une lettre avec .guess <lettre>', ...channelInfo }, { quoted: message });
                }
                break;
            case userMessage.startsWith('.trivia'):
                startTrivia(sock, chatId);
                break;
            case userMessage.startsWith('.answer'):
                const answer = userMessage.split(' ').slice(1).join(' ');
                if (answer) {
                    answerTrivia(sock, chatId, answer);
                } else {
                    sock.sendMessage(chatId, { text: 'Répondez avec .answer <réponse>', ...channelInfo }, { quoted: message });
                }
                break;
            case userMessage.startsWith('.compliment'):
                if (commands.compliment) await commands.compliment.complimentCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.insult'):
                if (commands.insult) await commands.insult.insultCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.8ball'):
                if (commands.eightball) {
                    const question = userMessage.split(' ').slice(1).join(' ');
                    await commands.eightball.eightBallCommand(sock, chatId, question);
                }
                break;
            case userMessage.startsWith('.lyrics'):
                if (commands.lyrics) {
                    const songTitle = userMessage.split(' ').slice(1).join(' ');
                    await commands.lyrics.lyricsCommand(sock, chatId, songTitle, message);
                }
                break;
            case userMessage.startsWith('.simp'):
                if (commands.simp) {
                    const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                    const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    await commands.simp.simpCommand(sock, chatId, quotedMsg, mentionedJid, senderId);
                }
                break;
            case userMessage.startsWith('.stupid') || userMessage.startsWith('.itssostupid') || userMessage.startsWith('.iss'):
                if (commands.stupid) {
                    const stupidQuotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                    const stupidMentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    const stupidArgs = userMessage.split(' ').slice(1);
                    await commands.stupid.stupidCommand(sock, chatId, stupidQuotedMsg, stupidMentionedJid, senderId, stupidArgs);
                }
                break;
            case userMessage === '.dare':
                if (commands.dare) await commands.dare.dareCommand(sock, chatId, message);
                break;
            case userMessage === '.truth':
                if (commands.truth) await commands.truth.truthCommand(sock, chatId, message);
                break;
            case userMessage === '.clear':
                if (isGroup && commands.clear) await commands.clear.clearCommand(sock, chatId);
                break;
            case userMessage.startsWith('.promote'):
                if (commands.promote) {
                    const mentionedJidListPromote = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    await commands.promote.promoteCommand(sock, chatId, mentionedJidListPromote, message);
                }
                break;
            case userMessage.startsWith('.demote'):
                if (commands.demote) {
                    const mentionedJidListDemote = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    await commands.demote.demoteCommand(sock, chatId, mentionedJidListDemote, message);
                }
                break;
            case userMessage === '.ping':
                if (commands.ping) await commands.ping(sock, chatId, message);
                break;
            case userMessage === '.alive':
                if (commands.alive) await commands.alive(sock, chatId, message);
                break;
            case userMessage.startsWith('.mention '):
                {
                    const args = userMessage.split(' ').slice(1).join(' ');
                    const isOwner = message.key.fromMe || senderIsSudo;
                    await mentionToggleCommand(sock, chatId, message, args, isOwner);
                }
                break;
            case userMessage === '.setmention':
                {
                    const isOwner = message.key.fromMe || senderIsSudo;
                    await setMentionCommand(sock, chatId, message, isOwner);
                }
                break;
            case userMessage.startsWith('.blur'):
                if (commands['img-blur']) {
                    const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                    await commands['img-blur'](sock, chatId, message, quotedMessage);
                }
                break;
            case userMessage.startsWith('.welcome'):
                if (isGroup && commands.welcome) {
                    if (!isSenderAdmin) {
                        const adminStatus = await isAdmin(sock, chatId, senderId);
                        isSenderAdmin = adminStatus.isSenderAdmin;
                    }
                    if (isSenderAdmin || message.key.fromMe) {
                        await commands.welcome.welcomeCommand(sock, chatId, message);
                    } else {
                        await sock.sendMessage(chatId, { text: 'Désolé, seuls les administrateurs du groupe peuvent utiliser cette commande.', ...channelInfo }, { quoted: message });
                    }
                } else {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans les groupes.', ...channelInfo }, { quoted: message });
                }
                break;
            case userMessage.startsWith('.goodbye'):
                if (isGroup && commands.goodbye) {
                    if (!isSenderAdmin) {
                        const adminStatus = await isAdmin(sock, chatId, senderId);
                        isSenderAdmin = adminStatus.isSenderAdmin;
                    }
                    if (isSenderAdmin || message.key.fromMe) {
                        await commands.goodbye.goodbyeCommand(sock, chatId, message);
                    } else {
                        await sock.sendMessage(chatId, { text: 'Désolé, seuls les administrateurs du groupe peuvent utiliser cette commande.', ...channelInfo }, { quoted: message });
                    }
                } else {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans les groupes.', ...channelInfo }, { quoted: message });
                }
                break;
            case userMessage === '.git':
            case userMessage === '.github':
            case userMessage === '.sc':
            case userMessage === '.script':
            case userMessage === '.repo':
                if (commands.github) await commands.github(sock, chatId, message);
                break;
            case userMessage.startsWith('.antibadword'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans les groupes.', ...channelInfo }, { quoted: message });
                    return;
                }
                const adminStatus = await isAdmin(sock, chatId, senderId);
                isSenderAdmin = adminStatus.isSenderAdmin;
                isBotAdmin = adminStatus.isBotAdmin;

                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, { text: '*Le bot doit être administrateur pour cette option*', ...channelInfo }, { quoted: message });
                    return;
                }
                if (commands.antibadword) await commands.antibadword(sock, chatId, message, senderId, isSenderAdmin);
                break;
            case userMessage.startsWith('.chatbot'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans les groupes.', ...channelInfo }, { quoted: message });
                    return;
                }
                const chatbotAdminStatus = await isAdmin(sock, chatId, senderId);
                if (!chatbotAdminStatus.isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, { text: '*Seuls les administrateurs ou le propriétaire peuvent utiliser cette commande*', ...channelInfo }, { quoted: message });
                    return;
                }
                const match = userMessage.slice(8).trim();
                await handleChatbotCommand(sock, chatId, message, match);
                break;
            case userMessage.startsWith('.take') || userMessage.startsWith('.steal'):
                if (commands.take) {
                    const isSteal = userMessage.startsWith('.steal');
                    const sliceLen = isSteal ? 6 : 5;
                    const takeArgs = rawText.slice(sliceLen).trim().split(' ');
                    await commands.take(sock, chatId, message, takeArgs);
                }
                break;
            case userMessage === '.flirt':
                if (commands.flirt) await commands.flirt.flirtCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.character'):
                if (commands.character) await commands.character(sock, chatId, message);
                break;
            case userMessage.startsWith('.waste'):
                if (commands.wasted) await commands.wasted(sock, chatId, message);
                break;
            case userMessage === '.ship':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans un groupe !', ...channelInfo }, { quoted: message });
                    return;
                }
                if (commands.ship) await commands.ship(sock, chatId, message);
                break;
            case userMessage === '.groupinfo' || userMessage === '.infogp' || userMessage === '.infogrupo':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans un groupe !', ...channelInfo }, { quoted: message });
                    return;
                }
                if (commands.groupinfo) await commands.groupinfo(sock, chatId, message);
                break;
            case userMessage === '.resetlink' || userMessage === '.revoke' || userMessage === '.anularlink':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans un groupe !', ...channelInfo }, { quoted: message });
                    return;
                }
                if (commands.resetlink) await commands.resetlink(sock, chatId, senderId);
                break;
            case userMessage === '.staff' || userMessage === '.admins' || userMessage === '.listadmin':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette commande ne peut être utilisée que dans un groupe !', ...channelInfo }, { quoted: message });
                    return;
                }
                if (commands.staff) await commands.staff(sock, chatId, message);
                break;
            case userMessage.startsWith('.tourl') || userMessage.startsWith('.url'):
                if (commands.url) await commands.url(sock, chatId, message);
                break;
            case userMessage.startsWith('.emojimix') || userMessage.startsWith('.emix'):
                if (commands.emojimix) await commands.emojimix(sock, chatId, message);
                break;
            case userMessage.startsWith('.tg') || userMessage.startsWith('.stickertelegram') || userMessage.startsWith('.tgsticker') || userMessage.startsWith('.telesticker'):
                if (commands.stickertelegram) await commands.stickertelegram(sock, chatId, message);
                break;
            case userMessage === '.vv':
                if (commands.viewonce) await commands.viewonce(sock, chatId, message);
                break;
            case userMessage === '.clearsession' || userMessage === '.clearsesi':
                if (commands.clearsession) await commands.clearsession(sock, chatId, message);
                break;
            case userMessage.startsWith('.autostatus'):
                if (commands.autostatus) {
                    const autoStatusArgs = userMessage.split(' ').slice(1);
                    await commands.autostatus.autoStatusCommand(sock, chatId, message, autoStatusArgs);
                }
                break;
            case userMessage.startsWith('.metallic'):
            case userMessage.startsWith('.ice'):
            case userMessage.startsWith('.snow'):
            case userMessage.startsWith('.impressive'):
            case userMessage.startsWith('.matrix'):
            case userMessage.startsWith('.light'):
            case userMessage.startsWith('.neon'):
            case userMessage.startsWith('.devil'):
            case userMessage.startsWith('.purple'):
            case userMessage.startsWith('.thunder'):
            case userMessage.startsWith('.leaves'):
            case userMessage.startsWith('.1917'):
            case userMessage.startsWith('.arena'):
            case userMessage.startsWith('.hacker'):
            case userMessage.startsWith('.sand'):
            case userMessage.startsWith('.blackpink'):
            case userMessage.startsWith('.glitch'):
            case userMessage.startsWith('.fire'):
                if (commands.textmaker) {
                    const style = userMessage.slice(1).split(' ')[0];
                    await commands.textmaker(sock, chatId, message, userMessage, style);
                }
                break;
            case userMessage.startsWith('.antidelete'):
                if (commands.antidelete) {
                    const antideleteMatch = userMessage.slice(11).trim();
                    await commands.antidelete.handleAntideleteCommand(sock, chatId, message, antideleteMatch);
                }
                break;
            case userMessage === '.surrender':
                await handleTicTacToeMove(sock, chatId, senderId, 'surrender');
                break;
            case userMessage === '.cleartmp':
                if (commands.cleartmp) await commands.cleartmp(sock, chatId, message);
                break;
            case userMessage === '.setpp':
                if (commands.setpp) await commands.setpp(sock, chatId, message);
                break;
            case userMessage.startsWith('.setgdesc'):
                if (commands.groupmanage) {
                    const text = rawText.slice(9).trim();
                    await commands.groupmanage.setGroupDescription(sock, chatId, senderId, text, message);
                }
                break;
            case userMessage.startsWith('.setgname'):
                if (commands.groupmanage) {
                    const text = rawText.slice(9).trim();
                    await commands.groupmanage.setGroupName(sock, chatId, senderId, text, message);
                }
                break;
            case userMessage.startsWith('.setgpp'):
                if (commands.groupmanage) {
                    await commands.groupmanage.setGroupPhoto(sock, chatId, senderId, message);
                }
                break;
            case userMessage.startsWith('.instagram') || userMessage.startsWith('.insta') || (userMessage === '.ig' || userMessage.startsWith('.ig ')):
                if (commands.instagram) await commands.instagram(sock, chatId, message);
                break;
            case userMessage.startsWith('.igsc'):
                if (commands.igs) await commands.igs.igsCommand(sock, chatId, message, true);
                break;
            case userMessage.startsWith('.igs'):
                if (commands.igs) await commands.igs.igsCommand(sock, chatId, message, false);
                break;
            case userMessage.startsWith('.fb') || userMessage.startsWith('.facebook'):
                if (commands.facebook) await commands.facebook(sock, chatId, message);
                break;
            case userMessage.startsWith('.music'):
                if (commands.play) await commands.play(sock, chatId, message);
                break;
            case userMessage.startsWith('.spotify'):
                if (commands.spotify) await commands.spotify(sock, chatId, message);
                break;
            case userMessage.startsWith('.play') || userMessage.startsWith('.mp3') || userMessage.startsWith('.ytmp3') || userMessage.startsWith('.song'):
                if (commands.song) await commands.song(sock, chatId, message);
                break;
            case userMessage.startsWith('.video') || userMessage.startsWith('.ytmp4'):
                if (commands.video) await commands.video(sock, chatId, message);
                break;
            case userMessage.startsWith('.tiktok') || userMessage.startsWith('.tt'):
                if (commands.tiktok) await commands.tiktok(sock, chatId, message);
                break;
            case userMessage.startsWith('.gpt') || userMessage.startsWith('.gemini'):
                if (commands.ai) await commands.ai(sock, chatId, message);
                break;
            case userMessage.startsWith('.translate') || userMessage.startsWith('.trt'):
                if (commands.translate) {
                    const commandLength = userMessage.startsWith('.translate') ? 10 : 4;
                    await commands.translate.handleTranslateCommand(sock, chatId, message, userMessage.slice(commandLength));
                    return;
                }
                break;
            case userMessage.startsWith('.ss') || userMessage.startsWith('.ssweb') || userMessage.startsWith('.screenshot'):
                if (commands.ss) {
                    const ssCommandLength = userMessage.startsWith('.screenshot') ? 11 : (userMessage.startsWith('.ssweb') ? 6 : 3);
                    await commands.ss.handleSsCommand(sock, chatId, message, userMessage.slice(ssCommandLength).trim());
                }
                break;
            case userMessage.startsWith('.areact') || userMessage.startsWith('.autoreact') || userMessage.startsWith('.autoreaction'):
                await handleAreactCommand(sock, chatId, message, isOwnerOrSudoCheck);
                break;
            case userMessage.startsWith('.sudo'):
                if (commands.sudo) await commands.sudo(sock, chatId, message);
                break;
            case userMessage === '.goodnight' || userMessage === '.lovenight' || userMessage === '.gn':
                if (commands.goodnight) await commands.goodnight.goodnightCommand(sock, chatId, message);
                break;
            case userMessage === '.shayari' || userMessage === '.shayri':
                if (commands.shayari) await commands.shayari.shayariCommand(sock, chatId, message);
                break;
            case userMessage === '.roseday':
                if (commands.roseday) await commands.roseday.rosedayCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.imagine') || userMessage.startsWith('.flux') || userMessage.startsWith('.dalle'):
                if (commands.imagine) await commands.imagine(sock, chatId, message);
                break;
            case userMessage === '.jid':
                await groupJidCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.autotyping'):
                if (commands.autotyping) {
                    await commands.autotyping.autotypingCommand(sock, chatId, message);
                    commandExecuted = true;
                }
                break;
            case userMessage.startsWith('.autoread'):
                if (commands.autoread) {
                    await commands.autoread.autoreadCommand(sock, chatId, message);
                    commandExecuted = true;
                }
                break;
            case userMessage.startsWith('.heart'):
                if (commands.misc) await commands.misc.handleHeart(sock, chatId, message);
                break;
            case userMessage.startsWith('.horny'):
            case userMessage.startsWith('.circle'):
            case userMessage.startsWith('.lgbt'):
            case userMessage.startsWith('.lolice'):
            case userMessage.startsWith('.simpcard'):
            case userMessage.startsWith('.tonikawa'):
            case userMessage.startsWith('.its-so-stupid'):
            case userMessage.startsWith('.namecard'):
            case userMessage.startsWith('.oogway2'):
            case userMessage.startsWith('.oogway'):
            case userMessage.startsWith('.tweet'):
            case userMessage.startsWith('.ytcomment'):
            case userMessage.startsWith('.comrade'):
            case userMessage.startsWith('.gay'):
            case userMessage.startsWith('.glass'):
            case userMessage.startsWith('.jail'):
            case userMessage.startsWith('.passed'):
            case userMessage.startsWith('.triggered'):
                if (commands.misc) {
                    const parts = userMessage.trim().split(/\s+/);
                    const sub = parts[0].slice(1);
                    const args = [sub, ...parts.slice(1)];
                    await commands.misc.miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.animu'):
                if (commands.anime) {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = parts.slice(1);
                    await commands.anime.animeCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.nom'):
            case userMessage.startsWith('.poke'):
            case userMessage.startsWith('.cry'):
            case userMessage.startsWith('.kiss'):
            case userMessage.startsWith('.pat'):
            case userMessage.startsWith('.hug'):
            case userMessage.startsWith('.wink'):
            case userMessage.startsWith('.facepalm'):
            case userMessage.startsWith('.face-palm'):
            case userMessage.startsWith('.animuquote'):
            case userMessage.startsWith('.loli'):
                if (commands.anime) {
                    const parts = userMessage.trim().split(/\s+/);
                    let sub = parts[0].slice(1);
                    if (sub === 'facepalm') sub = 'face-palm';
                    if (sub === 'animuquote') sub = 'quote';
                    await commands.anime.animeCommand(sock, chatId, message, [sub]);
                }
                break;
            case userMessage === '.crop':
                if (commands.stickercrop) await commands.stickercrop(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.pies'):
                const partsPies = rawText.trim().split(/\s+/);
                const argsPies = partsPies.slice(1);
                await piesCommand(sock, chatId, message, argsPies);
                commandExecuted = true;
                break;
            case userMessage === '.china':
            case userMessage === '.indonesia':
            case userMessage === '.japan':
            case userMessage === '.korea':
            case userMessage === '.india':
            case userMessage === '.malaysia':
            case userMessage === '.thailand':
                await piesAlias(sock, chatId, message, userMessage.slice(1));
                commandExecuted = true;
                break;
            case userMessage.startsWith('.update'):
                if (commands.update) {
                    const parts = rawText.trim().split(/\s+/);
                    const zipArg = parts[1] && parts[1].startsWith('http') ? parts[1] : '';
                    await commands.update(sock, chatId, message, zipArg);
                }
                commandExecuted = true;
                break;
            case userMessage.startsWith('.removebg') || userMessage.startsWith('.rmbg') || userMessage.startsWith('.nobg'):
                await removebgCommand.exec(sock, message, userMessage.split(' ').slice(1));
                break;
            case userMessage.startsWith('.remini') || userMessage.startsWith('.enhance') || userMessage.startsWith('.upscale'):
                await reminiCommand(sock, chatId, message, userMessage.split(' ').slice(1));
                break;
            case userMessage.startsWith('.sora'):
                if (commands.sora) await commands.sora(sock, chatId, message);
                break;
            default:
                if (isGroup) {
                    if (userMessage) {
                        await handleChatbotResponse(sock, chatId, message, userMessage, senderId);
                    }
                    await handleTagDetection(sock, chatId, message, senderId);
                    await handleMentionDetection(sock, chatId, message);
                }
                commandExecuted = false;
                break;
        }

        if (commandExecuted !== false) {
            await showTypingAfterCommand(sock, chatId);
        }

        async function groupJidCommand(sock, chatId, message) {
            const groupJid = message.key.remoteJid;

            if (!groupJid.endsWith('@g.us')) {
                return await sock.sendMessage(chatId, {
                    text: "❌ Cette commande ne peut être utilisée que dans un groupe."
                });
            }

            await sock.sendMessage(chatId, {
                text: `✅ Identifiant JID du Groupe : ${groupJid}`
            }, {
                quoted: message
            });
        }

        if (userMessage.startsWith('.')) {
            await addCommandReaction(sock, message);
        }
    } catch (error) {
        console.error('❌ Erreur dans le gestionnaire de messages :', error.message);
        if (chatId) {
            await sock.sendMessage(chatId, {
                text: '❌ Échec de l\'exécution de la commande !',
                ...channelInfo
            });
        }
    }
}

async function handleGroupParticipantUpdate(sock, update) {
    try {
        const { id, participants, action, author } = update;

        if (!id.endsWith('@g.us')) return;

        let isPublic = true;
        try {
            const modeData = JSON.parse(fs.readFileSync('./data/messageCount.json'));
            if (typeof modeData.isPublic === 'boolean') isPublic = modeData.isPublic;
        } catch (e) { }

        if (action === 'promote') {
            if (!isPublic) return;
            await handlePromotionEvent(sock, id, participants, author);
            return;
        }

        if (action === 'demote') {
            if (!isPublic) return;
            await handleDemotionEvent(sock, id, participants, author);
            return;
        }

        if (action === 'add') {
            await handleJoinEvent(sock, id, participants);
        }

        if (action === 'remove') {
            await handleLeaveEvent(sock, id, participants);
        }
    } catch (error) {
        console.error('Erreur dans handleGroupParticipantUpdate:', error);
    }
}

module.exports = {
    handleMessages,
    handleGroupParticipantUpdate,
    handleStatus: async (sock, status) => {
        await handleStatusUpdate(sock, status);
    }
};
