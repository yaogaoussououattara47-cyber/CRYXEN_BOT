const settings = {
  packname: 'CRYXEN BOT',
  author: '‎',
  botName: "CRYXEN BOT",
  botOwner: 'CRYXEN2109', // Votre nom / pseudo
  ownerNumber: '2250575514932', // Votre numéro au format international sans le signe +
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20,
  storeWriteInterval: 10000,
  description: "Bot WhatsApp polyvalent pour la gestion de groupes, l'automatisation et les commandes d'assistance.  BY CRYXEN2109 ",
  version: "1.0.0",
  updateZipUrl: "https://whatsapp.com/channel/0029VbDUrKRLCoWuL1ULWA0k" // Laissez vide si vous ne souhaitez pas utiliser de lien de mise à jour ZIP
};

module.exports = settings;
