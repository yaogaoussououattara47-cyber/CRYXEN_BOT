const settings = require('../settings');
const fs = require('fs');
const path = require('path');

/*
╔══════════════════════════════════════════╗
║        CRYXEN_BOT - AUTO MENU            ║
║  Les commandes sont détectées automatiquement ║
╚══════════════════════════════════════════╝
*/

// ─────────────────────────────────────────────
// CATÉGORIES
// ─────────────────────────────────────────────

const CATEGORIES = {
    GENERAL: {
        icon: '⚡',
        names: [
            'menu', 'help', 'alive', 'ping', 'owner',
            'botinfo', 'info', 'about', 'runtime', 'uptime'
        ]
    },

    GROUPE: {
        icon: '⚙️',
        names: [
            'tagall', 'hidetag', 'kick', 'add', 'promote',
            'demote', 'mute', 'unmute', 'group', 'admins',
            'antilink', 'welcome', 'goodbye', 'setname',
            'setdesc', 'linkgroup', 'revoke'
        ]
    },

    MEDIA: {
        icon: '✦',
        names: [
            'play', 'song', 'music', 'video', 'ytmp3',
            'ytmp4', 'youtube', 'tiktok', 'spotify',
            'sticker', 'stickerly', 'gif', 'photo',
            'image', 'media', 'download'
        ]
    },

    ANIME: {
        icon: '𖤐',
        names: [
            'anime', 'manga', 'waifu', 'neko',
            'quote', 'naruto', 'madara', 'wallpaper'
        ]
    },

    FUN: {
        icon: '☠',
        names: [
            'joke', 'fun', 'game', 'quiz', 'truth',
            'dare', 'ship', 'rate', 'roast', 'fact'
        ]
    },

    IA: {
        icon: '◈',
        names: [
            'ai', 'gpt', 'chatgpt', 'gemini',
            'imagine', 'ask', 'translate'
        ]
    },

    UTILITAIRE: {
        icon: '◆',
        names: [
            'short', 'tinyurl', 'qr', 'weather',
            'calc', 'calculator', 'convert', 'search',
            'google', 'define'
        ]
    },

    OWNER: {
        icon: '♜',
        names: [
            'broadcast', 'restart', 'update', 'shutdown',
            'eval', 'exec', 'shell', 'setprefix',
            'setbotname', 'block', 'unblock'
        ]
    }
};


// ─────────────────────────────────────────────
// DÉTECTER AUTOMATIQUEMENT LA CATÉGORIE
// ─────────────────────────────────────────────

function detectCategory(commandName, filePath) {

    const name = commandName.toLowerCase();

    // 1. Si le fichier est dans un dossier portant
    //    le nom d'une catégorie, on utilise ce dossier.
    const parentFolder = path.basename(path.dirname(filePath)).toUpperCase();

    if (CATEGORIES[parentFolder]) {
        return parentFolder;
    }

    // 2. Recherche exacte du nom de commande
    for (const [category, data] of Object.entries(CATEGORIES)) {
        if (data.names.includes(name)) {
            return category;
        }
    }

    // 3. Recherche par mots-clés
    for (const [category, data] of Object.entries(CATEGORIES)) {
        if (
            data.names.some(keyword =>
                name.includes(keyword)
            )
        ) {
            return category;
        }
    }

    // 4. Commande inconnue
    return 'AUTRES';
}


// ─────────────────────────────────────────────
// LECTURE DES COMMANDES
// ─────────────────────────────────────────────

function getCommandFiles(dir) {

    let results = [];

    if (!fs.existsSync(dir)) {
        return results;
    }

    const files = fs.readdirSync(dir, { withFileTypes: true });

    for (const file of files) {

        const fullPath = path.join(dir, file.name);

        // Permet aussi de détecter les commandes
        // placées dans des sous-dossiers.
        if (file.isDirectory()) {
            results = results.concat(
                getCommandFiles(fullPath)
            );
        }

        else if (
            file.isFile() &&
            file.name.endsWith('.js') &&
            file.name !== 'help.js'
        ) {
            results.push(fullPath);
        }
    }

    return results;
}


// ─────────────────────────────────────────────
// CONSTRUCTION DU MENU
// ─────────────────────────────────────────────

function buildMenu(commandFiles) {

    const categories = {};

    // Préparer les catégories
    for (const category of Object.keys(CATEGORIES)) {
        categories[category] = [];
    }

    categories.AUTRES = [];

    // Classer automatiquement chaque commande
    for (const file of commandFiles) {

        const commandName = path
            .basename(file, '.js')
            .toLowerCase();

        const category = detectCategory(
            commandName,
            file
        );

        categories[category].push(commandName);
    }

    // Trier alphabétiquement
    for (const category of Object.keys(categories)) {
        categories[category].sort();
    }

    let menu = '';

    // ─────────────────────────────────────────
    // AFFICHAGE DES CATÉGORIES
    // ─────────────────────────────────────────

    for (const [category, commands] of Object.entries(categories)) {

        // Ne pas afficher une catégorie vide
        if (commands.length === 0) {
            continue;
        }

        let icon = '◇';

        if (CATEGORIES[category]) {
            icon = CATEGORIES[category].icon;
        }

        menu += `\n╭─〔 𓆩${icon}𓆪 ${category} 〕\n`;

        // 3 commandes par ligne
        for (let i = 0; i < commands.length; i += 3) {

            const line = commands
                .slice(i, i + 3)
                .map(command => `.${command}`)
                .join('  ');

            menu += `│ ${line}\n`;
        }

        menu += `╰━━━━━━━━━━━━━━━\n`;
    }

    return menu;
}


// ─────────────────────────────────────────────
// COMMANDE MENU
// ─────────────────────────────────────────────

async function helpCommand(sock, chatId, message) {

    try {

        // Dossier commands
        const commandsDir = __dirname;

        // Récupérer automatiquement les fichiers
        const commandFiles = getCommandFiles(commandsDir);

        // Construire automatiquement le menu
        const commandMenu = buildMenu(commandFiles);

        // Infos bot
        const owner = settings.botOwner || 'Owner';
        const version = settings.version || '1.0.0';

        // ─────────────────────────────────────
        // MENU CRYXEN
        // ─────────────────────────────────────

        const helpMessage = `
╭━━〔 𓆩༒︎𝐂𝐑𝐘𝐗𝐄𝐍_𝐁𝐎𝐓༒︎𓆪 〕━━╮
┃ 𖤐 ᴏᴡɴᴇʀ   : ${owner}
┃ 𖤐 ᴠᴇʀsɪᴏɴ : ${version}
┃ 𖤐 ᴘʀᴇғɪx  : 「 . 」
┃ 𖤐 sᴛᴀᴛᴜs  : ᴏɴʟɪɴᴇ
┃ 𖤐 ᴄᴏᴍᴍᴀɴᴅᴇs : ${commandFiles.length}
╰━━━━━━━━━━━━━━━━╯
${commandMenu}
╭─〔 𓆩❖𓆪 𝐀𝐈𝐃𝐄 〕
│ .help <commande>
│ Ex: .help ping
╰━━━━━━━━━━━━━━━

╰─〔 𓆩𖤐𓆪 𝐂𝐑𝐘𝐗𝐄𝐍²¹⁰⁹ 〕─╯
`;

        // ─────────────────────────────────────
        // IMAGE
        // ─────────────────────────────────────

        const imagePath = path.join(
            __dirname,
            '../assets/bot_image.jpg'
        );

        // ─────────────────────────────────────
        // AUDIO
        // ─────────────────────────────────────

        const audioPath = path.join(
            __dirname,
            '../assets/menu.mp3'
        );

        // Envoyer le menu avec image
        if (fs.existsSync(imagePath)) {

            const imageBuffer = fs.readFileSync(
                imagePath
            );

            await sock.sendMessage(
                chatId,
                {
                    image: imageBuffer,
                    caption: helpMessage
                },
                {
                    quoted: message
                }
            );

        } else {

            // Sinon texte uniquement
            await sock.sendMessage(
                chatId,
                {
                    text: helpMessage
                },
                {
                    quoted: message
                }
            );
        }

        // ─────────────────────────────────────
        // AUDIO AUTOMATIQUE
        // ─────────────────────────────────────

        if (fs.existsSync(audioPath)) {

            const audioBuffer = fs.readFileSync(
                audioPath
            );

            await sock.sendMessage(
                chatId,
                {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    ptt: true
                },
                {
                    quoted: message
                }
            );
        }

    } catch (error) {

        console.error(
            'Erreur dans la commande menu:',
            error
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    '❌ Une erreur est survenue lors de l’affichage du menu.'
            },
            {
                quoted: message
            }
        );
    }
}


// ─────────────────────────────────────────────
// EXPORT
// ─────────────────────────────────────────────

module.exports = helpCommand;
Ce qui est intéressant avec cette version
Tu ajoutes par exemple :


commands/
├── ping.js
├── alive.js
├── tagall.js
├── kick.js
├── play.js
├── sticker.js
├── anime.js
└── nouvellecommande.js
Tu ne touches plus au help.js.

Le bot détecte automatiquement :


.ping
.alive
dans GENERAL,


.tagall
.kick
dans GROUPE,


.play
.sticker
dans MEDIA,

etc.

Et nouvellecommande.js, si le bot ne sait pas encore dans quelle catégorie la mettre, ira automatiquement dans :


╭─〔 𓆩◇𓆪 AUTRES 〕
│ .nouvellecommande
╰━━━━━━━━━━━━━━━
Encore mieux pour la suite
On pourra faire une V2 vraiment intelligente où chaque fichier de commande peut déclarer lui-même :

JavaScript

category: 'MEDIA'
ou

JavaScript

category: 'OWNER'
sans jamais modifier le menu. Ainsi, même si tu as 100 ou 200 commandes, le menu se construit automatiquement.

Important : ton ancien code utilise __dirname comme dossier des commandes. Donc cette version reste volontairement compatible avec cette architecture au lieu de te forcer à restructurer tout ton bot.







Vous avez dit :
Voici le lien de l'image https://files.catbox.moe/qv21rw.jpg
je veux aussi une réaction automatique sur la command .menu avant d'envoyer le menu ajoute ces modifications au code sans la caser





ChatGPT a dit :
Oui frérot. On peut intégrer les deux sans casser le fonctionnement actuel :

Réaction automatique au message .menu avant l’envoi du menu.

Image Catbox utilisée directement comme image du menu.

On garde la détection automatique des commandes, l’audio et le système de secours si l’image ne peut pas être envoyée.

La réaction se fait avant l’envoi du menu.

Voici le help.js complet à remplacer :

JavaScript

const settings = require('../settings');
const fs = require('fs');
const path = require('path');

/*
╔══════════════════════════════════════════╗
║        CRYXEN_BOT - AUTO MENU            ║
║  Menu dynamique + réaction automatique   ║
╚══════════════════════════════════════════╝
*/

// ─────────────────────────────────────────────
// IMAGE DU MENU
// ─────────────────────────────────────────────

const MENU_IMAGE_URL = 'https://files.catbox.moe/qv21rw.jpg';


// ─────────────────────────────────────────────
// CATÉGORIES
// ─────────────────────────────────────────────

const CATEGORIES = {

    GENERAL: {
        icon: '⚡',
        names: [
            'menu', 'help', 'alive', 'ping', 'owner',
            'botinfo', 'info', 'about', 'runtime', 'uptime'
        ]
    },

    GROUPE: {
        icon: '⚙️',
        names: [
            'tagall', 'hidetag', 'kick', 'add', 'promote',
            'demote', 'mute', 'unmute', 'group', 'admins',
            'antilink', 'welcome', 'goodbye', 'setname',
            'setdesc', 'linkgroup', 'revoke'
        ]
    },

    MEDIA: {
        icon: '✦',
        names: [
            'play', 'song', 'music', 'video', 'ytmp3',
            'ytmp4', 'youtube', 'tiktok', 'spotify',
            'sticker', 'stickerly', 'gif', 'photo',
            'image', 'media', 'download'
        ]
    },

    ANIME: {
        icon: '𖤐',
        names: [
            'anime', 'manga', 'waifu', 'neko',
            'quote', 'naruto', 'madara', 'wallpaper'
        ]
    },

    FUN: {
        icon: '☠',
        names: [
            'joke', 'fun', 'game', 'quiz', 'truth',
            'dare', 'ship', 'rate', 'roast', 'fact'
        ]
    },

    IA: {
        icon: '◈',
        names: [
            'ai', 'gpt', 'chatgpt', 'gemini',
            'imagine', 'ask', 'translate'
        ]
    },

    UTILITAIRE: {
        icon: '◆',
        names: [
            'short', 'tinyurl', 'qr', 'weather',
            'calc', 'calculator', 'convert', 'search',
            'google', 'define'
        ]
    },

    OWNER: {
        icon: '♜',
        names: [
            'broadcast', 'restart', 'update', 'shutdown',
            'eval', 'exec', 'shell', 'setprefix',
            'setbotname', 'block', 'unblock'
        ]
    }
};


// ─────────────────────────────────────────────
// DÉTECTION AUTOMATIQUE DE LA CATÉGORIE
// ─────────────────────────────────────────────

function detectCategory(commandName, filePath) {

    const name = commandName.toLowerCase();

    // Si le fichier se trouve dans un dossier
    // correspondant à une catégorie
    const parentFolder =
        path.basename(path.dirname(filePath)).toUpperCase();

    if (CATEGORIES[parentFolder]) {
        return parentFolder;
    }

    // Recherche exacte
    for (const [category, data] of Object.entries(CATEGORIES)) {

        if (data.names.includes(name)) {
            return category;
        }
    }

    // Recherche par mot-clé
    for (const [category, data] of Object.entries(CATEGORIES)) {

        if (
            data.names.some(keyword =>
                name.includes(keyword)
            )
        ) {
            return category;
        }
    }

    // Si aucune catégorie trouvée
    return 'AUTRES';
}


// ─────────────────────────────────────────────
// RÉCUPÉRATION DES COMMANDES
// ─────────────────────────────────────────────

function getCommandFiles(dir) {

    let results = [];

    if (!fs.existsSync(dir)) {
        return results;
    }

    const files = fs.readdirSync(dir, {
        withFileTypes: true
    });

    for (const file of files) {

        const fullPath =
            path.join(dir, file.name);

        // Sous-dossiers
        if (file.isDirectory()) {

            results = results.concat(
                getCommandFiles(fullPath)
            );
        }

        // Fichiers JS
        else if (
            file.isFile() &&
            file.name.endsWith('.js') &&
            file.name !== 'help.js'
        ) {

            results.push(fullPath);
        }
    }

    return results;
}


// ─────────────────────────────────────────────
// CONSTRUCTION DU MENU
// ─────────────────────────────────────────────

function buildMenu(commandFiles) {

    const categories = {};

    // Initialiser les catégories
    for (const category of Object.keys(CATEGORIES)) {
        categories[category] = [];
    }

    categories.AUTRES = [];

    // Classer les commandes
    for (const file of commandFiles) {

        const commandName =
            path.basename(file, '.js').toLowerCase();

        const category =
            detectCategory(commandName, file);

        categories[category].push(commandName);
    }

    // Tri alphabétique
    for (const category of Object.keys(categories)) {
        categories[category].sort();
    }

    let menu = '';

    // Construire chaque catégorie
    for (const [category, commands] of
        Object.entries(categories)) {

        // Ne pas afficher les catégories vides
        if (commands.length === 0) {
            continue;
        }

        let icon = '◇';

        if (CATEGORIES[category]) {
            icon = CATEGORIES[category].icon;
        }

        menu +=
            `\n╭─〔 𓆩${icon}𓆪 ${category} 〕\n`;

        // 3 commandes par ligne
        for (
            let i = 0;
            i < commands.length;
            i += 3
        ) {

            const line =
                commands
                    .slice(i, i + 3)
                    .map(command => `.${command}`)
                    .join('  ');

            menu += `│ ${line}\n`;
        }

        menu +=
            `╰━━━━━━━━━━━━━━━\n`;
    }

    return menu;
}


// ─────────────────────────────────────────────
// COMMANDE .MENU
// ─────────────────────────────────────────────

async function helpCommand(sock, chatId, message) {

    try {

        // ─────────────────────────────────────
        // 1. RÉACTION AUTOMATIQUE
        // ─────────────────────────────────────

        try {

            await sock.sendMessage(
                chatId,
                {
                    react: {
                        text: '⚡',
                        key: message.key
                    }
                }
            );

        } catch (reactionError) {

            // Si la réaction échoue,
            // le menu continue quand même.
            console.log(
                '⚠️ Réaction impossible :',
                reactionError.message
            );
        }


        // ─────────────────────────────────────
        // 2. DOSSIER DES COMMANDES
        // ─────────────────────────────────────

        const commandsDir = __dirname;


        // ─────────────────────────────────────
        // 3. DÉTECTION AUTOMATIQUE
        // ─────────────────────────────────────

        const commandFiles =
            getCommandFiles(commandsDir);


        // ─────────────────────────────────────
        // 4. CONSTRUCTION DU MENU
        // ─────────────────────────────────────

        const commandMenu =
            buildMenu(commandFiles);


        // ─────────────────────────────────────
        // 5. INFORMATIONS DU BOT
        // ─────────────────────────────────────

        const owner =
            settings.botOwner || 'Owner';

        const version =
            settings.version || '1.0.0';


        // ─────────────────────────────────────
        // 6. MENU CRYXEN
        // ─────────────────────────────────────

        const helpMessage = `
╭━━〔 𓆩༒︎𝐂𝐑𝐘𝐗𝐄𝐍_𝐁𝐎𝐓༒︎𓆪 〕━━╮
┃ 𖤐 ᴏᴡɴᴇʀ   : ${owner}
┃ 𖤐 ᴠᴇʀsɪᴏɴ : ${version}
┃ 𖤐 ᴘʀᴇғɪx  : 「 . 」
┃ 𖤐 sᴛᴀᴛᴜs  : ᴏɴʟɪɴᴇ
┃ 𖤐 ᴄᴏᴍᴍᴀɴᴅᴇs : ${commandFiles.length}
╰━━━━━━━━━━━━━━━━╯
${commandMenu}
╭─〔 𓆩❖𓆪 𝐀𝐈𝐃𝐄 〕
│ .help <commande>
│ Ex: .help ping
╰━━━━━━━━━━━━━━━

╰─〔 𓆩𖤐𓆪 𝐂𝐑𝐘𝐗𝐄𝐍²¹⁰⁹ 〕─╯
`;


        // ─────────────────────────────────────
        // 7. ENVOI DU MENU AVEC IMAGE CATBOX
        // ─────────────────────────────────────

        try {

            await sock.sendMessage(
                chatId,
                {
                    image: {
                        url: MENU_IMAGE_URL
                    },
                    caption: helpMessage
                },
                {
                    quoted: message
                }
            );

        } catch (imageError) {

            // Si Catbox ne répond pas,
            // le bot envoie quand même le menu en texte.

            console.log(
                '⚠️ Image du menu indisponible :',
                imageError.message
            );

            await sock.sendMessage(
                chatId,
                {
                    text: helpMessage
                },
                {
                    quoted: message
                }
            );
        }


        // ─────────────────────────────────────
        // 8. AUDIO AUTOMATIQUE
        // ─────────────────────────────────────

        const audioPath =
            path.join(
                __dirname,
                '../assets/menu.mp3'
            );

        if (fs.existsSync(audioPath)) {

            try {

                const audioBuffer =
                    fs.readFileSync(audioPath);

                await sock.sendMessage(
                    chatId,
                    {
                        audio: audioBuffer,
                        mimetype: 'audio/mpeg',
                        ptt: true
                    },
                    {
                        quoted: message
                    }
                );

            } catch (audioError) {

                console.log(
                    '⚠️ Erreur audio :',
                    audioError.message
                );
            }
        }

    } catch (error) {

        console.error(
            '❌ Erreur dans la commande menu:',
            error
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    '❌ Une erreur est survenue lors de l’affichage du menu.'
            },
            {
                quoted: message
            }
        );
    }
}


// ─────────────────────────────────────────────
// EXPORT
// ─────────────────────────────────────────────

module.exports = helpCommand;
