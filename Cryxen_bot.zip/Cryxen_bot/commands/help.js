const settings = require('../settings');
const fs = require('fs');
const path = require('path');

/*
╔══════════════════════════════════════════╗
║        CRYXEN_BOT - MENU                 ║
║  Design soigné + réaction automatique    ║
╚══════════════════════════════════════════╝
*/

// ─────────────────────────────────────────────
// CATÉGORIES (regroupement par mot-clé sur le nom du fichier)
// ─────────────────────────────────────────────

const CATEGORIES = {
    GENERAL: {
        icon: '⚡',
        names: ['menu', 'help', 'alive', 'ping', 'owner', 'botinfo', 'info', 'about', 'runtime', 'uptime']
    },
    GROUPE: {
        icon: '⚙️',
        names: ['tagall', 'hidetag', 'kick', 'add', 'promote', 'demote', 'mute', 'unmute', 'group', 'admins', 'antilink', 'welcome', 'goodbye', 'setname', 'setdesc', 'linkgroup', 'revoke']
    },
    MEDIA: {
        icon: '✦',
        names: ['play', 'song', 'music', 'video', 'ytmp3', 'ytmp4', 'youtube', 'tiktok', 'spotify', 'sticker', 'stickerly', 'gif', 'photo', 'image', 'media', 'download']
    },
    ANIME: {
        icon: '𖤐',
        names: ['anime', 'manga', 'waifu', 'neko', 'quote', 'naruto', 'madara', 'wallpaper']
    },
    FUN: {
        icon: '☠',
        names: ['joke', 'fun', 'game', 'quiz', 'truth', 'dare', 'ship', 'rate', 'roast', 'fact']
    },
    IA: {
        icon: '◈',
        names: ['ai', 'gpt', 'chatgpt', 'gemini', 'imagine', 'ask', 'translate']
    },
    UTILITAIRE: {
        icon: '◆',
        names: ['short', 'tinyurl', 'qr', 'weather', 'calc', 'calculator', 'convert', 'search', 'google', 'define']
    },
    OWNER: {
        icon: '♜',
        names: ['broadcast', 'restart', 'update', 'shutdown', 'eval', 'exec', 'shell', 'setprefix', 'setbotname', 'block', 'unblock']
    }
};

function detectCategory(commandName) {
    const name = commandName.toLowerCase();

    for (const [category, data] of Object.entries(CATEGORIES)) {
        if (data.names.includes(name)) {
            return category;
        }
    }

    for (const [category, data] of Object.entries(CATEGORIES)) {
        if (data.names.some(keyword => name.includes(keyword))) {
            return category;
        }
    }

    return 'AUTRES';
}

// ─────────────────────────────────────────────
// CONSTRUCTION DU MENU (design soigné)
// ─────────────────────────────────────────────

function buildMenu(commandFiles) {
    const categories = {};
    for (const category of Object.keys(CATEGORIES)) {
        categories[category] = [];
    }
    categories.AUTRES = [];

    commandFiles.forEach(file => {
        const commandName = file.replace('.js', '').toLowerCase();
        const category = detectCategory(commandName);
        categories[category].push(commandName);
    });

    for (const category of Object.keys(categories)) {
        categories[category].sort();
    }

    let menu = '';

    for (const [category, commands] of Object.entries(categories)) {
        if (commands.length === 0) continue;

        const icon = CATEGORIES[category] ? CATEGORIES[category].icon : '◇';

        menu += `\n╭──❰ 𓆩${icon}𓆪 ${category} ❱──╮\n`;

        for (let i = 0; i < commands.length; i += 3) {
            const line = commands.slice(i, i + 3).map(c => `.${c}`).join('  ');
            menu += `│ ${line}\n`;
        }

        menu += `╰────────────────╯\n`;
    }

    return menu;
}

// ─────────────────────────────────────────────
// COMMANDE .MENU
// ─────────────────────────────────────────────

async function helpCommand(sock, chatId, message) {
    try {
        // 1. Réaction automatique (échec silencieux si non supportée)
        try {
            await sock.sendMessage(chatId, {
                react: { text: '⚡', key: message.key }
            });
        } catch (reactionError) {
            console.log('⚠️ Réaction impossible :', reactionError.message);
        }

        // 2. Lecture plate du dossier commands (identique à l'ancienne version)
        const commandsDir = __dirname;
        const files = fs.readdirSync(commandsDir);
        const commandFiles = files.filter(file => file.endsWith('.js') && file !== 'help.js');

        // 3. Construction du menu par catégories
        const commandMenu = buildMenu(commandFiles);

        // 4. Infos bot
        const owner = settings.botOwner || 'Owner';
        const version = settings.version || '1.0.0';

        // 5. Message final avec design soigné
        const helpMessage = `╭─❰ ⚡ 𝗖𝗥𝗬𝗫𝗘𝗡 𝗠𝗘𝗡𝗨 ⚡ ❱─╮

   🟢 𝑺𝒚𝒔𝒕𝒆̀𝒎𝒆 𝒂𝒄𝒕𝒊𝒇

├─────────────────────
│ 👑 Propriétaire  : ${owner}
│ 🔧 Version       : v${version}
│ 📌 Préfixe       : 「 . 」
│ 📦 Commandes     : ${commandFiles.length}
├─────────────────────
${commandMenu}
╭──❰ 𓆩❖𓆪 𝗔𝗜𝗗𝗘 ❱──╮
│ .help <commande>
│ Ex : .help ping
╰────────────────╯

   𖤐 𝘓𝘦 𝘴𝘺𝘴𝘵𝘦̀𝘮𝘦 𝘯𝘦 𝘥𝘰𝘳𝘵 𝘫𝘢𝘮𝘢𝘪𝘴 𖤐

╰──❰ 𝑪𝑹𝒀𝑿𝑬𝑵²¹⁰⁹ ❱──╯`;

        // 6. Image locale (assets/menu.jpg)
        const imagePath = path.join(__dirname, '../assets/menu.jpg');
        const audioPath = path.join(__dirname, '../assets/menu.mp3');

        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, {
                text: helpMessage
            }, { quoted: message });
        }

        // 7. Audio automatique
        if (fs.existsSync(audioPath)) {
            const audioBuffer = fs.readFileSync(audioPath);
            await sock.sendMessage(chatId, {
                audio: audioBuffer,
                mimetype: 'audio/mp4',
                ptt: true
            }, { quoted: message });
        }

    } catch (error) {
        console.error('❌ Erreur dans la commande menu:', error);
        await sock.sendMessage(chatId, {
            text: '❌ Une erreur est survenue lors de l\'affichage du menu.'
        }, { quoted: message });
    }
}

module.exports = helpCommand;