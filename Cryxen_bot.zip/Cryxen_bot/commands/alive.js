const fs = require('fs');
const path = require('path');
const settings = require('../settings');
const { runtime } = require('../lib/myfunc');

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🖼️ IMAGE LOCALE CRYXEN ALIVE
// Image récupérée dans le dossier assets/ à la racine du projet
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const ALIVE_IMG_PATH = path.join(__dirname, '..', 'assets', 'alive.jpg');

// Valeurs statiques lues une seule fois (pas à chaque appel)
const VERSION = settings?.version || "2.0.0";
const OWNER = settings?.botOwner || "CRYXEN2109";

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎞️ EFFET DÉFILEMENT (marquee)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

/**
 * Découpe un texte en une série de "frames" qui donnent
 * l'impression qu'il défile de droite à gauche en boucle.
 */
function buildMarqueeFrames(text, width = 16) {
    const padded = `${text}   `; // espace entre deux boucles du texte
    const loop = padded.repeat(2); // pour pouvoir boucler sans trou
    const frames = [];
    for (let i = 0; i < padded.length; i++) {
        frames.push(loop.substring(i, i + width));
    }
    return frames;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ⚡ CRYXEN ALIVE SYSTEM (optimisé)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
module.exports = async (sock, chatId, message) => {
    try {
        const pushname = message?.pushName || message?.verifiedBizName || "Âme Inconnue";

        // Date native au lieu de moment.js -> plus léger et plus rapide
        const now = new Date();
        const currentTime = now.toLocaleTimeString("fr-FR", { hour12: false });

        const uptime = runtime
            ? runtime(process.uptime())
            : `${Math.floor(process.uptime() / 3600)}h ${Math.floor((process.uptime() % 3600) / 60)}m`;

        // Message compact mais avec un design plus soigné
        const msg = `╭─❰ ⚡ 𝗖𝗥𝗬𝗫𝗘𝗡 𝗔𝗟𝗜𝗩𝗘 ⚡ ❱─╮

   🟢 𝑺𝒚𝒔𝒕𝒆̀𝒎𝒆 𝒂𝒄𝒕𝒊𝒇

├─────────────────────
│ 👤 Utilisateur   : ${pushname}
│ ⏰ Heure         : ${currentTime}
│ ♾️ Uptime        : ${uptime}
│ 🔧 Version       : v${VERSION}
│ 👑 Propriétaire  : ${OWNER}
├─────────────────────

   𖤐 𝘓𝘦 𝘴𝘺𝘴𝘵𝘦̀𝘮𝘦 𝘯𝘦 𝘥𝘰𝘳𝘵 𝘫𝘢𝘮𝘢𝘪𝘴 𖤐

╰──❰ 𝑪𝑹𝒀𝑿𝑬𝑵²¹⁰⁹ ❱──╯`;

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 🎞️ ANIMATION "CRYXEN_BOT" QUI DÉFILE
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        try {
            const frames = buildMarqueeFrames("CRYXEN_BOT", 16);
            const sentAnim = await sock.sendMessage(
                chatId,
                { text: `〔 ${frames[0]} 〕` },
                { quoted: message }
            );

            for (let i = 1; i < frames.length; i++) {
                await delay(250);
                await sock.sendMessage(chatId, {
                    text: `〔 ${frames[i]} 〕`,
                    edit: sentAnim.key
                });
            }
        } catch (animErr) {
            // Si l'édition de message n'est pas supportée par la version de Baileys,
            // on ignore simplement l'animation et on continue avec la carte finale
            console.warn("⚠️ Animation défilante indisponible :", animErr.message);
        }

        // On vérifie que le fichier existe avant d'essayer de l'envoyer
        if (fs.existsSync(ALIVE_IMG_PATH)) {
            await sock.sendMessage(
                chatId,
                { image: fs.readFileSync(ALIVE_IMG_PATH), caption: msg },
                { quoted: message }
            );
        } else {
            // Pas d'image trouvée -> on envoie quand même le texte pour ne pas bloquer la commande
            console.warn(`⚠️ Image introuvable : ${ALIVE_IMG_PATH}`);
            await sock.sendMessage(
                chatId,
                { text: msg },
                { quoted: message }
            );
        }

    } catch (err) {
        console.error("❌ Erreur dans la commande .alive :", err);
        await sock.sendMessage(chatId, {
            text: `╭─〔 ❌ ERREUR CRYXEN 〕\n│ La commande Alive a rencontré une erreur.\n│ ${err.message}\n╰────────────`
        }).catch(() => {});
    }
};