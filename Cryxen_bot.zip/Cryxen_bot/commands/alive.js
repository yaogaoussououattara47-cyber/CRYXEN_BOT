
Ouvrir la barre latérale

ChatGPT
Offre gratuite

ChatGPT a dit :
Oui frérot. On peut intégrer les deux sans casser le fonctionnement actuel :

Réaction automatique au message .menu avant l’envoi du menu.

Image Catbox utilisée directement comme image du menu.

On garde la détection automatique des commandes, l’audio et le système de secours si l’image ne peut pas être envoyée.

La réaction se fait avant l’envoi du menu.

Voici le help.js complet à remplacer :

JavaScript

const settings = require('../settings');
const fs = require('fs');
const path = require('path');

/*
╔══════════════════════════════════════════╗
║        CRYXEN_BOT - AUTO MENU            ║
║  Menu dynamique + réaction automatique   ║
╚══════════════════════════════════════════╝
*/

// ─────────────────────────────────────────────
// IMAGE DU MENU
// ─────────────────────────────────────────────

const MENU_IMAGE_URL = 'https://files.catbox.moe/qv21rw.jpg';


// ─────────────────────────────────────────────
// CATÉGORIES
// ─────────────────────────────────────────────

const CATEGORIES = {

    GENERAL: {
        icon: '⚡',
        names: [
            'menu', 'help', 'alive', 'ping', 'owner',
            'botinfo', 'info', 'about', 'runtime', 'uptime'
        ]
    },

    GROUPE: {
        icon: '⚙️',
        names: [
            'tagall', 'hidetag', 'kick', 'add', 'promote',
            'demote', 'mute', 'unmute', 'group', 'admins',
            'antilink', 'welcome', 'goodbye', 'setname',
            'setdesc', 'linkgroup', 'revoke'
        ]
    },

    MEDIA: {
        icon: '✦',
        names: [
            'play', 'song', 'music', 'video', 'ytmp3',
            'ytmp4', 'youtube', 'tiktok', 'spotify',
            'sticker', 'stickerly', 'gif', 'photo',
            'image', 'media', 'download'
        ]
    },

    ANIME: {
        icon: '𖤐',
        names: [
            'anime', 'manga', 'waifu', 'neko',
            'quote', 'naruto', 'madara', 'wallpaper'
        ]
    },

    FUN: {
        icon: '☠',
        names: [
            'joke', 'fun', 'game', 'quiz', 'truth',
            'dare', 'ship', 'rate', 'roast', 'fact'
        ]
    },

    IA: {
        icon: '◈',
        names: [
            'ai', 'gpt', 'chatgpt', 'gemini',
            'imagine', 'ask', 'translate'
        ]
    },

    UTILITAIRE: {
        icon: '◆',
        names: [
            'short', 'tinyurl', 'qr', 'weather',
            'calc', 'calculator', 'convert', 'search',
            'google', 'define'
        ]
    },

    OWNER: {
        icon: '♜',
        names: [
            'broadcast', 'restart', 'update', 'shutdown',
            'eval', 'exec', 'shell', 'setprefix',
            'setbotname', 'block', 'unblock'
        ]
    }
};


// ─────────────────────────────────────────────
// DÉTECTION AUTOMATIQUE DE LA CATÉGORIE
// ─────────────────────────────────────────────

function detectCategory(commandName, filePath) {

    const name = commandName.toLowerCase();

    // Si le fichier se trouve dans un dossier
    // correspondant à une catégorie
    const parentFolder =
        path.basename(path.dirname(filePath)).toUpperCase();

    if (CATEGORIES[parentFolder]) {
        return parentFolder;
    }

    // Recherche exacte
    for (const [category, data] of Object.entries(CATEGORIES)) {

        if (data.names.includes(name)) {
            return category;
        }
    }

    // Recherche par mot-clé
    for (const [category, data] of Object.entries(CATEGORIES)) {

        if (
            data.names.some(keyword =>
                name.includes(keyword)
            )
        ) {
            return category;
        }
    }

    // Si aucune catégorie trouvée
    return 'AUTRES';
}


// ─────────────────────────────────────────────
// RÉCUPÉRATION DES COMMANDES
// ─────────────────────────────────────────────

function getCommandFiles(dir) {

    let results = [];

    if (!fs.existsSync(dir)) {
        return results;
    }

    const files = fs.readdirSync(dir, {
        withFileTypes: true
    });

    for (const file of files) {

        const fullPath =
            path.join(dir, file.name);

        // Sous-dossiers
        if (file.isDirectory()) {

            results = results.concat(
                getCommandFiles(fullPath)
            );
        }

        // Fichiers JS
        else if (
            file.isFile() &&
            file.name.endsWith('.js') &&
            file.name !== 'help.js'
        ) {

            results.push(fullPath);
        }
    }

    return results;
}


// ─────────────────────────────────────────────
// CONSTRUCTION DU MENU
// ─────────────────────────────────────────────

function buildMenu(commandFiles) {

    const categories = {};

    // Initialiser les catégories
    for (const category of Object.keys(CATEGORIES)) {
        categories[category] = [];
    }

    categories.AUTRES = [];

    // Classer les commandes
    for (const file of commandFiles) {

        const commandName =
            path.basename(file, '.js').toLowerCase();

        const category =
            detectCategory(commandName, file);

        categories[category].push(commandName);
    }

    // Tri alphabétique
    for (const category of Object.keys(categories)) {
        categories[category].sort();
    }

    let menu = '';

    // Construire chaque catégorie
    for (const [category, commands] of
        Object.entries(categories)) {

        // Ne pas afficher les catégories vides
        if (commands.length === 0) {
            continue;
        }

        let icon = '◇';

        if (CATEGORIES[category]) {
            icon = CATEGORIES[category].icon;
        }

        menu +=
            `\n╭─〔 𓆩${icon}𓆪 ${category} 〕\n`;

        // 3 commandes par ligne
        for (
            let i = 0;
            i < commands.length;
            i += 3
        ) {

            const line =
                commands
                    .slice(i, i + 3)
                    .map(command => `.${command}`)
                    .join('  ');

            menu += `│ ${line}\n`;
        }

        menu +=
            `╰━━━━━━━━━━━━━━━\n`;
    }

    return menu;
}


// ─────────────────────────────────────────────
// COMMANDE .MENU
// ─────────────────────────────────────────────

async function helpCommand(sock, chatId, message) {

    try {

        // ─────────────────────────────────────
        // 1. RÉACTION AUTOMATIQUE
        // ─────────────────────────────────────

        try {

            await sock.sendMessage(
                chatId,
                {
                    react: {
                        text: '⚡',
                        key: message.key
                    }
                }
            );

        } catch (reactionError) {

            // Si la réaction échoue,
            // le menu continue quand même.
            console.log(
                '⚠️ Réaction impossible :',
                reactionError.message
            );
        }


        // ─────────────────────────────────────
        // 2. DOSSIER DES COMMANDES
        // ─────────────────────────────────────

        const commandsDir = __dirname;


        // ─────────────────────────────────────
        // 3. DÉTECTION AUTOMATIQUE
        // ─────────────────────────────────────

        const commandFiles =
            getCommandFiles(commandsDir);


        // ─────────────────────────────────────
        // 4. CONSTRUCTION DU MENU
        // ─────────────────────────────────────

        const commandMenu =
            buildMenu(commandFiles);


        // ─────────────────────────────────────
        // 5. INFORMATIONS DU BOT
        // ─────────────────────────────────────

        const owner =
            settings.botOwner || 'Owner';

        const version =
            settings.version || '1.0.0';


        // ─────────────────────────────────────
        // 6. MENU CRYXEN
        // ─────────────────────────────────────

        const helpMessage = `
╭━━〔 𓆩༒︎𝐂𝐑𝐘𝐗𝐄𝐍_𝐁𝐎𝐓༒︎𓆪 〕━━╮
┃ 𖤐 ᴏᴡɴᴇʀ   : ${owner}
┃ 𖤐 ᴠᴇʀsɪᴏɴ : ${version}
┃ 𖤐 ᴘʀᴇғɪx  : 「 . 」
┃ 𖤐 sᴛᴀᴛᴜs  : ᴏɴʟɪɴᴇ
┃ 𖤐 ᴄᴏᴍᴍᴀɴᴅᴇs : ${commandFiles.length}
╰━━━━━━━━━━━━━━━━╯
${commandMenu}
╭─〔 𓆩❖𓆪 𝐀𝐈𝐃𝐄 〕
│ .help <commande>
│ Ex: .help ping
╰━━━━━━━━━━━━━━━

╰─〔 𓆩𖤐𓆪 𝐂𝐑𝐘𝐗𝐄𝐍²¹⁰⁹ 〕─╯
`;


        // ─────────────────────────────────────
        // 7. ENVOI DU MENU AVEC IMAGE CATBOX
        // ─────────────────────────────────────

        try {

            await sock.sendMessage(
                chatId,
                {
                    image: {
                        url: MENU_IMAGE_URL
                    },
                    caption: helpMessage
                },
                {
                    quoted: message
                }
            );

        } catch (imageError) {

            // Si Catbox ne répond pas,
            // le bot envoie quand même le menu en texte.

            console.log(
                '⚠️ Image du menu indisponible :',
                imageError.message
            );

            await sock.sendMessage(
                chatId,
                {
                    text: helpMessage
                },
                {
                    quoted: message
                }
            );
        }


        // ─────────────────────────────────────
        // 8. AUDIO AUTOMATIQUE
        // ─────────────────────────────────────

        const audioPath =
            path.join(
                __dirname,
                '../assets/menu.mp3'
            );

        if (fs.existsSync(audioPath)) {

            try {

                const audioBuffer =
                    fs.readFileSync(audioPath);

                await sock.sendMessage(
                    chatId,
                    {
                        audio: audioBuffer,
                        mimetype: 'audio/mpeg',
                        ptt: true
                    },
                    {
                        quoted: message
                    }
                );

            } catch (audioError) {

                console.log(
                    '⚠️ Erreur audio :',
                    audioError.message
                );
            }
        }

    } catch (error) {

        console.error(
            '❌ Erreur dans la commande menu:',
            error
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    '❌ Une erreur est survenue lors de l’affichage du menu.'
            },
            {
                quoted: message
            }
        );
    }
}


// ─────────────────────────────────────────────
// EXPORT
// ─────────────────────────────────────────────

module.exports = helpCommand;
Ce qui se passe maintenant
Quand quelqu'un écrit :


.menu
le bot fait dans cet ordre :


.menu
   ↓
⚡ réaction automatique
   ↓
📸 image Catbox
   ↓
📋 menu CRYXEN_BOT
   ↓
🎵 audio menu.mp3
Et surtout, une erreur de réaction ou de chargement de l'image ne bloque pas le menu : j'ai mis des try/catch séparés pour éviter de casser la commande.

⚠️ Petite précision importante : avec cette version, les nouvelles commandes inconnues seront automatiquement placées dans AUTRES. Pour avoir un système où même une nouvelle commande est automatiquement envoyée dans la bonne catégorie sans jamais modifier help.js, il faudra faire une V2 où chaque fichier de commande déclare lui-même sa catégorie. C'est la solution vraiment propre pour ton objectif.







Vous avez dit :
Envoi le code en fichier pdf




ChatGPT a dit :
Data analysis isn't available right now. Do you want to continue without it? 






Vous avez dit :
Tu va me crée un autre Alive bien plus stylé et professionnel, unique en son genre, du jamais vus sur les autre bot que l'encien ci

const path = require('path');
const moment = require('moment');
const settings = require('../settings');
const { runtime } = require('../lib/myfunc');

const ALIVE_IMG = "https://files.catbox.moe/szkk1l.jpg";

module.exports = async (sock, chatId, message) => {
try {
const pushname = message.pushName || "Âme Perdue";
const now = moment();
const currentTime = now.format("HH:mm:ss");
const currentDate = now.format("DD/MM/YYYY");

    const uptime = runtime ? runtime(process.uptime()) : `${Math.floor(process.uptime() / 3600)}h ${Math.floor((process.uptime() % 3600) / 60)}m`;

    const msg = `
☠️─────☠️─────☠️─────☠️─────☠️─────
⚡ C R Y X E N 2 1 0 9 ⚡
☠️─────☠️─────☠️─────☠️─────☠️─────

👤 Bienvenue, ${pushname}...
🕰️ Heure infernale: ${currentTime}
📅 Date funeste: ${currentDate}
⏳ Temps d’activité: ${uptime}
⚙️ Version: 2.0.0

──────────────────────────────
🔥 Le démon est éveillé et rôde.
💀 ⚡ C R Y X E N 2 1 0 9 ⚡ ne dort jamais...
──────────────────────────────`;

    await sock.sendMessage(chatId, {
        image: { url: ALIVE_IMG },
        caption: msg
    }, { quoted: message });

} catch (err) {
    console.error("Erreur dans la commande .alive :", err);
    await sock.sendMessage(chatId, {
        text: `❌ *⚠️ Commande Alive brisée :*\n${err.message}`
    }, { quoted: message });
}
};

Voici la nouvelle image à ajouté à alive https://files.catbox.moe/tsde3x.png


Afficher plus




ChatGPT a dit :
Oui frérot. Je peux te refaire le .alive avec une identité beaucoup plus premium : moins “bot classique”, plus interface système CRYXEN, avec une structure visuelle reconnaissable et une ambiance sombre/démoniaque.

Je garde ton image tsde3x.png et les infos dynamiques (nom, heure, date, uptime, version).

JavaScript

const moment = require('moment');
const settings = require('../settings');
const { runtime } = require('../lib/myfunc');

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🖼️ IMAGE OFFICIELLE CRYXEN ALIVE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const ALIVE_IMG = "https://files.catbox.moe/tsde3x.png";


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ⚡ CRYXEN ALIVE SYSTEM
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

module.exports = async (sock, chatId, message) => {

    try {

        const pushname =
            message.pushName || "Âme Inconnue";

        const now = moment();

        const currentTime =
            now.format("HH:mm:ss");

        const currentDate =
            now.format("DD • MM • YYYY");

        const uptime =
            runtime
                ? runtime(process.uptime())
                : `${Math.floor(process.uptime() / 3600)}h ` +
                  `${Math.floor((process.uptime() % 3600) / 60)}m`;

        const version =
            settings.version || "2.0.0";

        const owner =
            settings.botOwner || "CRYXEN2109";


        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 🩸 MESSAGE ALIVE
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

        const msg = `

╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃        𓆩༒︎ 𝐂𝐑𝐘𝐗𝐄𝐍 𓆪
┃        𝐀𝐋𝐈𝐕𝐄 𝐒𝐘𝐒𝐓𝐄𝐌
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

        𖤐 𝐒𝐘𝐒𝐓𝐄𝐌 𝐎𝐍𝐋𝐈𝐍𝐄 𖤐

╭─〔 𝐔𝐒𝐄𝐑 〕
│ 𓆩👤𓆪 𝐍𝐨𝐦    : ${pushname}
│ 𓆩◈𓆪 𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐀𝐂𝐓𝐈𝐕𝐄
╰──────────────────────────────

╭─〔 𝐒𝐘𝐒𝐓𝐄𝐌 〕
│ 𓆩⚡𓆪 𝐇𝐞𝐮𝐫𝐞  : ${currentTime}
│ 𓆩◷𓆪 𝐃𝐚𝐭𝐞   : ${currentDate}
│ 𓆩♾𓆪 𝐔𝐩𝐭𝐢𝐦𝐞 : ${uptime}
│ 𓆩◆𓆪 𝐕𝐞𝐫𝐬𝐢𝐨𝐧: ${version}
╰──────────────────────────────

╭─〔 𝐂𝐑𝐘𝐗𝐄𝐍 𝐂𝐎𝐑𝐄 〕
│
│  𓆩⚡𓆪 𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐈𝐎𝐍 : 𝐒𝐓𝐀𝐁𝐋𝐄
│  𓆩◈𓆪 𝐂𝐎𝐑𝐄       : 𝐑𝐔𝐍𝐍𝐈𝐍𝐆
│  𓆩𖤐𓆪 𝐒𝐓𝐀𝐓𝐔𝐒      : 𝐀𝐋𝐈𝐕𝐄
│
╰──────────────────────────────

      𓆩༒︎𓆪 𝐓𝐇𝐄 𝐒𝐘𝐒𝐓𝐄𝐌 𝐃𝐎𝐄𝐒 𝐍𝐎𝐓 𝐒𝐋𝐄𝐄𝐏 𓆩༒︎𓆪

╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃ 𖤐 𝐂𝐑𝐘𝐗𝐄𝐍²¹⁰⁹
┃ 𖤐 𝐎𝐖𝐍𝐄𝐑 : ${owner}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

`;

        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // 📡 ENVOI
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

        await sock.sendMessage(
            chatId,
            {
                image: {
                    url: ALIVE_IMG
                },
                caption: msg
            },
            {
                quoted: message
            }
        );

    } catch (err) {

        console.error(
            "❌ Erreur dans la commande .alive :",
            err
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    `╭─〔 ❌ 𝐂𝐑𝐘𝐗𝐄𝐍 𝐄𝐑𝐑𝐎𝐑 〕\n` +
                    `│ La commande Alive a rencontré une erreur.\n` +
                    `│\n` +
                    `│ ${err.message}\n` +
                    `╰────────────────────`
            },
            {
                quoted: message
            }
        );
    }
};
