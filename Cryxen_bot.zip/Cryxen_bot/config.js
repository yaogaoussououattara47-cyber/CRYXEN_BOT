require('dotenv').config();

// ⚙️ Configurations générales
global.ownername = 'CRYXEN2109';
global.botname = 'CRYXEN BOT';
global.owner = ['2250575514932'];
global.packname = 'CRYXEN BOT';
global.author = '⚡ C R Y X E N 2 1 0 9 ⚡';

// 🌐 Liste des API REST externes
global.APIs = {
    xteam: 'https://api.xteam.xyz',
    dzx: 'https://api.dhamzxploit.my.id',
    lol: 'https://api.lolhuman.xyz',
    violetics: 'https://violetics.pw',
    neoxr: 'https://api.neoxr.my.id',
    zenzapis: 'https://zenzapis.xyz',
    akuari: 'https://api.akuari.my.id',
    akuari2: 'https://apimu.my.id',
    nrtm: 'https://fg-nrtm.ddns.net',
    bg: 'http://bochil.ddns.net',
    fgmods: 'https://api-fgmods.ddns.net'
};

// 🔑 Clés API externes
global.APIKeys = {
    'https://api.xteam.xyz': 'd90a9e986e18778b',
    'https://api.lolhuman.xyz': '85faf717d0545d14074659ad',
    'https://api.neoxr.my.id': 'yourkey',
    'https://violetics.pw': 'beta',
    'https://zenzapis.xyz': 'yourkey',
    'https://api-fgmods.ddns.net': 'fg-dylux'
};

module.exports = {
    WARN_COUNT: 3, // Nombre d'avertissements avant expulsion du groupe
    APIs: global.APIs,
    APIKeys: global.APIKeys
};
